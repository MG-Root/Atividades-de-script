#!/bin/bash

echo "É só uma fase ruim, logo vai piorar."
